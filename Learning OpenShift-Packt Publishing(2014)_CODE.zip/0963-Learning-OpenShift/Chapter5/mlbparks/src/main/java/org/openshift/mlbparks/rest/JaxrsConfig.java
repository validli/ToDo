package org.openshift.mlbparks.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/ws")
public class JaxrsConfig extends Application{

}
