Sample application for the book "Learning OpenShift"

To try this application out, enter in the following URL which will allow you to deploy this applicaiton on OpenShift Online:

http://goo.gl/pwXN5D


