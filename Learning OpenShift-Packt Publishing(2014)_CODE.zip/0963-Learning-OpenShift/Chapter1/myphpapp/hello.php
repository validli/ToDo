<?php

echo "Hello, Cloud!";
