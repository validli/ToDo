DROP TABLE IF EXISTS `users`;
   CREATE TABLE `users` (
     `user_id` int(11) NOT NULL AUTO_INCREMENT,
     `username` varchar(200) DEFAULT NULL,
     PRIMARY KEY (`user_id`)
   ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
   LOCK TABLES `users` WRITE;
   INSERT INTO `users` VALUES (1,'gshipley');
   UNLOCK TABLES;
